package com.tcs.netbanking.bean;

	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;
	import java.time.LocalDateTime;

	@Entity
	@Table(name = "transactionhistory")
	public class TransactionHistory {

	    @Id
	    private int transactionId;

	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "account_id")
	    private Account account;

	    @NotNull
	    @Positive(message = "amount must be positive")
	    private int amount;

	    @Column(name = "date")
	    private String date;

		public int getTransactionId() {
			return transactionId;
		}

		public void setTransactionId(int transactionId) {
			this.transactionId = transactionId;
		}

		public Account getAccount() {
			return account;
		}

		public void setAccount(Account account) {
			this.account = account;
		}

		public int getAmount() {
			return amount;
		}

		public void setAmount(int amount) {
			this.amount = amount;
		}

		public String getDate() {
			return date;
		}

		public void setDate(String date) {
			this.date = date;
		}

		public TransactionHistory(int transactionId, Account account,
				@NotNull @Positive(message = "amount must be positive") int amount, String date) {
			super();
			this.transactionId = transactionId;
			this.account = account;
			this.amount = amount;
			this.date = date;
		}

		public TransactionHistory() {
			super();
		}

		
	    
	    
	    
	}


